// Note: starter tutorial was used
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define NANOVG_GL2_IMPLEMENTATION
#include "glfw3.h"
#include "nanovg.h"
#include "nanovg_gl.h"

#define FRAME_W 400
#define FRAME_H 300

// global variables to set
int frequency = 5;
char note = 'A';
int x_loc = 100;
int y_loc = 100;

void error_cb(int code, const char* description){
    fprintf(stderr, "Error: %s\n", description);
}

int main(void) {
    GLFWwindow* window;

    glfwSetErrorCallback(error_cb);
    if(!glfwInit()){
        exit(EXIT_FAILURE);
    }

    //create window using GLFW library and OpenGL for context
    window = glfwCreateWindow(FRAME_W, FRAME_H, "Hello World!", NULL, NULL);
    if(!window){
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    // make current context window
    glfwMakeContextCurrent(window);

    // start NanoVG which is the graphics library
    NVGcontext* visualGraphics = nvgCreateGL2(NVG_ANTIALIAS | NVG_STENCIL_STROKES);
    if(visualGraphics == NULL) {
        fprintf(stderr, "Could not start nanovg\n");
        exit(EXIT_FAILURE);
    }

    // main code
    while (!glfwWindowShouldClose(window))
    {
        /* code */
        //clear background
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

        // start frame for drawing
        nvgBeginFrame(visualGraphics, FRAME_W, FRAME_H, 1);

        // draw "hello world" at a specific position
        nvgFontSize(visualGraphics, 55.0f);
        nvgFontFace(visualGraphics, "sans");
        nvgFillColor(visualGraphics, nvgRGBA(255,255,255,255)); // all high => white
        
        char screenPrint [100];
        sprintf(screenPrint, "Hello World! Frequency: %d        Note: %c\n", frequency, note);
        
        nvgText(visualGraphics, x_loc, y_loc, screenPrint, NULL); // print at location 100, 100

        // end drawing
        nvgEndFrame(visualGraphics);

        // swap buffers to display
        glfwSwapBuffers(window);

        // poll for and process events
        glfwPollEvents();

    }
    
    // finish 
    nvgDeleteGL2(visualGraphics);
    glfwDestroyWindow(window);
    glfwTerminate();

    exit(EXIT_SUCCESS);
}
