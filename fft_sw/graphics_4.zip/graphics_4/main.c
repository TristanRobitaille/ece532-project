#include "raylib.h"
#include "stdlib.h"
#include "stdio.h"

// global variables to set
int frequency = 5;
char note = 'A';
int x_loc = 250;
int y_loc = 400;

#define MAX_FRAME_DELAY     200
#define MIN_FRAME_DELAY      1

int main(void) {
    // Initialize window and graphics context
    const int screenWidth = 800; // may need to update in the future (HD is 1280 x 720 pixels)
    const int screenHeight = 600;
    InitWindow(screenWidth, screenHeight, "ECE532 Music Analyser");

    // start of gif
    int animFrames = 0;

    // Load all GIF animation frames into a single Image
    // NOTE: GIF data is always loaded as RGBA (32bit) by default
    // NOTE: Frames are just appended one after another in image.data memory
    Image trumpetGif = LoadImageAnim("resources/trumpet-music.gif", &animFrames);
    //Image trumpetGif = LoadImageAnim("resources/trumpet_player.png", &animFrames);
    printf("Pixel Size Image: %d\n", GetPixelDataSize(trumpetGif.width, trumpetGif.height, PIXELFORMAT_UNCOMPRESSED_R32G32B32A32));

    char screenPrint [100];  
    Vector2 textSize;    

    // Load texture from image
    // NOTE: We will update this texture when required with next frame data
    // WARNING: It's not recommended to use this technique for sprites animation,
    // use spritesheets instead, like illustrated in textures_sprite_anim example
    Texture2D trumpetGifTexture = LoadTextureFromImage(trumpetGif);

    unsigned int nextFrameDataOffset = 0;  // Current byte offset to next frame in image.data

    int currentAnimFrame = 0;       // Current animation frame to load and draw
    int frameDelay = 120;             // Frame delay to switch between animation frames
    int frameCounter = 0;           // General frames counter

     //display clef
    /*Image clef = LoadImage("resources/treble_clef.png");
    ImageCrop(&clef, (Rectangle){100, 10, 280, 380});
    ImageResize(&clef, 100, 200);
    //ImageDrawPixel(&clef, 10, 10, RAYWHITE);
    ImageDraw(&trumpetGif, clef, (Rectangle){ 0, 0, (float)clef.width, (float)clef.height }, (Rectangle){ 30, 40, clef.width*1.5f, clef.height*1.5f }, WHITE); */

    SetTargetFPS(60);               // Set our game to run at 60 frames-per-second
    // end of gif

    // Main game loop
    while (!WindowShouldClose()) {
        // Update
        //start of gif
        frameCounter++;
        if (frameCounter >= frameDelay)
        {
            // Move to next frame
            // NOTE: If final frame is reached we return to first frame
            note++;
            currentAnimFrame++;
            if (note >= 'H') note = 'A';
            if(currentAnimFrame >= animFrames) currentAnimFrame = 0;

            // Get memory offset position for next frame data in image.data
            frequency = trumpetGif.width*trumpetGif.height*4*currentAnimFrame;
            //frequency = trumpetGif.width*trumpetGif.height*4*(int)note;
            nextFrameDataOffset = trumpetGif.width*trumpetGif.height*4*currentAnimFrame;

            // Update GPU texture data with next frame image data
            // WARNING: Data size (frame size) and pixel format must match already created texture
            UpdateTexture(trumpetGifTexture, ((unsigned char *)trumpetGif.data) + nextFrameDataOffset);

            frameCounter = 0;
        }
        if (frameDelay > MAX_FRAME_DELAY) frameDelay = MAX_FRAME_DELAY;
        else if (frameDelay < MIN_FRAME_DELAY) frameDelay = MIN_FRAME_DELAY;
        //end of gif
        
        
        // Draw
        BeginDrawing();
            ClearBackground(RAYWHITE);
            //gif
            sprintf(screenPrint, "Welcome to the Music Analyser!\n\n\n\n\n       Frequency: %02i\n\n               Note: %c\n", frequency, note);
            textSize = MeasureTextEx(GetFontDefault(), screenPrint, (float)20, 1.0f);
            

            DrawTexture(trumpetGifTexture, GetScreenWidth()/2 - trumpetGifTexture.width/2, 140, WHITE);

            DrawText("(c) 2024\nMusic Analyser by Group 2", screenWidth - 150, screenHeight - 30, 10, GRAY);
            //gif
            // Draw text at coordinates (100, 200) with font size 20
            DrawText(screenPrint, x_loc, y_loc, 20, BLACK);

        EndDrawing();
    }
    printf("Pixel Size Text: %d\n", GetPixelDataSize(textSize.x, textSize.y, PIXELFORMAT_UNCOMPRESSED_R32G32B32A32));  
    textSize = MeasureTextEx(GetFontDefault(), "(c) 2024\nMusic Analyser by Group 2", (float)10, 1.0f);
    printf("Pixel Size Copyright: %d\n", GetPixelDataSize(textSize.x, textSize.y, PIXELFORMAT_UNCOMPRESSED_R32G32B32A32));  

    // Close window and clean up resources
    CloseWindow();

    return 0;
}
