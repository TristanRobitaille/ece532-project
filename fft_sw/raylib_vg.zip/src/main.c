#include "raylib.h"

// global variables to set
int frequency = 5;
char note = 'A';
int x_loc = 100;
int y_loc = 100;

int main(void) {
    // Initialize window and graphics context
    const int screenWidth = 800;
    const int screenHeight = 600;
    InitWindow(screenWidth, screenHeight, "Raylib Starts!");

    // Main game loop
    while (!WindowShouldClose()) {
        // Update

        // Draw
        BeginDrawing();
        ClearBackground(RAYWHITE);

        char screenPrint [100];
        sprintf(screenPrint, "Hello World! Frequency: %d        Note: %c\n", frequency, note);
        // Draw text at coordinates (100, 200) with font size 20
        DrawText(screenPrint, x_loc, y_loc, 20, BLACK);

        EndDrawing();
    }

    // Close window and clean up resources
    CloseWindow();

    return 0;
}
